// e412.cpp
// main program


#include"complex.h"

//----- Main Function -----
int main()
{
	ComplexFrac cf(2,5);				// A complex number is created
	cf.print();							// Complex number is printed on the screen
	return 0;
}
